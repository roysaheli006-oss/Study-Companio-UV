export const firebaseConfig = {
  "projectId": "studio-847445113-74945",
  "appId": "1:1001069703653:web:97a3f49b8a1e7bb024bf0c",
  "apiKey": "AIzaSyDUyubM-2JtMditjtV2-6lhaMF6WNEm-Qo",
  "authDomain": "studio-847445113-74945.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "1001069703653"
};
